/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Musza
 */
public class Omnivora {
    private final String diet;
    
    
    public Omnivora(String diet) {
        this.diet = diet ;
    }
        
    public String diet() {
        return diet;
    } 
}
